from django.apps import AppConfig


class App41Config(AppConfig):
    name = 'app4_2'
