from django.apps import AppConfig


class App43Config(AppConfig):
    name = 'app4_3'
