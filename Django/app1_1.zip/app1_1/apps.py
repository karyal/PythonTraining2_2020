from django.apps import AppConfig


class App11Config(AppConfig):
    name = 'app1_1'
